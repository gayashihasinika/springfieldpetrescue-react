import React from "react";
import img1 from '../assets/images/icon1.png'
import img2 from '../assets/images/icon2.png'
import img3 from '../assets/images/icon3.png'
import img4 from '../assets/images/icon4.png'
import '../assets/css/footer.css';

export default function Footer() {
    return (
        <footer className="footer">
            <div className="footer-content">
                <div className="footer-section about">
                    <h3>About Springfield Pet Rescue</h3>
                    <p>
                        We are dedicated to rescuing, rehabilitating, and rehoming stray and abandoned animals. Our mission is to
                        create a safe and caring community for every animal in need.
                    </p>
                </div>

                <div className="footer-section links">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="/donate">Donate</a></li>
                        <li><a href="/adopt">Adopt</a></li>
                        <li><a href="/volunteer">Volunteer</a></li>
                        <li><a href="/contact">Contact Us</a></li>
                    </ul>
                </div>

                <div className="footer-section contact">
                    <h3>Contact Us</h3>
                    <p><i className="fas fa-map-marker-alt"></i> 123 Rescue St, Springfield, SL</p>
                    <p><i className="fas fa-phone"></i> +94 123 456 789</p>
                    <p><i className="fas fa-envelope"></i> info@springfieldpetrescue.com</p>
                    <div className="social-links">
                        <a href="https://www.facebook.com/springfieldpetrescue" target="_blank" rel="noopener noreferrer">
                            <img className="icon" src={img1} alt="Facebook" />
                            <i className="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://www.instagram.com/springfieldpetrescue" target="_blank" rel="noopener noreferrer">
                            <img className="icon" src={img2} alt="Instagram" />
                            <i className="fab fa-instagram"></i>
                        </a>
                        <a href="https://twitter.com/springfieldpetrescue" target="_blank" rel="noopener noreferrer">
                            <img className="icon" src={img3} alt="Twitter" />
                            <i className="fab fa-twitter"></i>
                        </a>
                        <a href="https://tiktok.com/springfieldpetrescue" target="_blank" rel="noopener noreferrer">
                            <img className="icon" src={img4} alt="TikTok" />
                            <i className="fab fa-tiktok"></i>
                        </a>
                    </div>

                </div>
            </div>

            <div className="footer-bottom">
                <p>&copy; 2024 Springfield Pet Rescue and Rehome. All Rights Reserved.</p>
            </div>
        </footer>
    );
}
