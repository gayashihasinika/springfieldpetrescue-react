import React from 'react';
import img1 from '../assets/images/1.jpg';
import '../assets/css/header.css';

export default function Header() {
    return (
        <div className="container">
            <div className="top">
                <img className="imgl" src={img1} alt="Springfield Pet Rescue" />
                <h1>Springfield Pet Rescue and Rehome</h1>
            </div>
        </div>
    );
}
