import React from 'react'
import '../assets/css/menu.css'

export default function Menu() {
  return (
    <ul>
      <li><a href="/">Home</a>  </li>
      <li><a href="/usermanagement">User Management </a></li>
      <li><a href="/petmanagement">Pet Management </a></li>
      <li><a href="/see-all-district">See All Cities</a></li>
      <li><a target='blank' href="http://localhost/springfield_petrescue/index.php">Springfield Petrescue</a> </li>
    </ul>
  )
}