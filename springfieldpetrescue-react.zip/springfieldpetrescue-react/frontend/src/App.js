import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/homePage";
import Layout from "./components/Layout";
import UserManagement from "./pages/usermanagement";
import Cities from "./pages/cities";
import PetManagement from "./pages/petmanagement";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route key={"Layout"} path="/" element={<Layout />}>
          <Route key={"homePage"} path="/" element={<Home />} />
          <Route key={"usermanagement"} path="/usermanagement" element={<UserManagement />} />
          <Route key={"cities"} path="/see-all-district" element={<Cities />} />
          <Route key={"petmanagement"} path="/petmanagement" element={<PetManagement />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
