import React, { useEffect } from "react";
import '../assets/css/home.css';


const Home = () => {
    // Effect to display alert based on URL parameters
    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const status = urlParams.get('status');
        const message = urlParams.get('message');

        if (status && message) {
            alert(message);
        }
    }, []);

    return (
        <>
            <div className="banner">
                <div className="overlay"></div>
                <div className="banner-content">
                    <h1>Welcome to Springfield Pet Rescue</h1>
                    <p>Join us in making a difference in the lives of stray dogs through rescue, rehabilitation, and rehoming.</p>
                </div>
            </div>
            </>
    );
}

export default Home;
