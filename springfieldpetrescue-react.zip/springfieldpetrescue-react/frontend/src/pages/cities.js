import React, { useState, useEffect } from "react";
import apiClient from "../service/axiosService";
import { apis } from "../Apis/apis";
import { Col, Row, Card } from "antd";

const Cities = () => {
  const [citiesList, setCitiesList] = useState([]);

  useEffect(() => {
    getCities();
  }, []);

  const getCities = async () => {
    const response = await apiClient.get(apis.getCities);
    if (response.status == 200) {
      setCitiesList(response.data);
    }
  };
  return (
    <Row>
      {citiesList.map((cities, index) => (
        <Col sm={3} key={index}>
          <Card
            style={{
              margin: "10px",
              textAlign: "center",
              backgroundColor: "darkgray",
            }}
          >
            {cities.names[0]?.name}
          </Card>
        </Col>
      ))}
        
    </Row>
  );
};
export default Cities;
