import React from "react";
import image1 from "./../assets/images/images1.jpg";
const Colombo =()=>{
    return (
        <><h1>Colombo</h1><p>The commercial capital city of the Sri Lanka is Colombo.</p>
        <img src={image1} alt="birds" />
   
        </>

    )
}
export default Colombo;