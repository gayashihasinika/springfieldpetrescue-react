import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/petmanagement.css';

const PetManagement = () => {
  const [pets, setPets] = useState([]);
  const [name, setName] = useState('');
  const [breed, setBreed] = useState('');
  const [species, setSpecies] = useState('');
  const [age, setAge] = useState('');
  const [sex, setSex] = useState('');
  const [color, setColor] = useState('');
  const [size, setSize] = useState('');
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchPets();
  }, []);

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
     
      if (editId !== null) {
        // Update pet
        await axios.put(`http://localhost:3001/pets/${editId}`, { name, breed, species, age, sex, color, size});
      } else {
        // Add new pet
        await axios.post('http://localhost:3001/pets', { name, breed, species, age, sex, color, size});
      }

      // Clear form fields
      setName('');
      setBreed('');
      setSpecies('');
      setAge('');
      setSex('');
      setColor('');
      setSize('');
      setEditId(null);
      fetchPets(); // Refresh the pet list after submission
    } catch (error) {
      console.error('Error submitting form', error);
    }
  };

  // Handle edit pet
  const handleEdit = (pet) => {
    setName(pet.name);
    setBreed(pet.breed);
    setSpecies(pet.species);
    setAge(pet.age);
    setSex(pet.sex);
    setColor(pet.color);
    setSize(pet.size);
    setEditId(pet.id);
  };

  // Handle delete pet
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/pets/${id}`);
      fetchPets(); // Refresh the pet list after deletion
    } catch (error) {
      console.error('Error deleting pet', error);
    }
  };

  // Fetch all pets from backend
  const fetchPets = async () => {
    try {
      const response = await axios.get('http://localhost:3001/pets');
      setPets(response.data);
    } catch (error) {
      console.error('Error fetching pets', error);
    }
  };

  return (
    <div className="container">
      <h2 className="header">Pet Management</h2>
      <form className="form" onSubmit={handleSubmit}>
        <input
          className="input-field"
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Breed"
          value={breed}
          onChange={(e) => setBreed(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Species"
          value={species}
          onChange={(e) => setSpecies(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Sex"
          value={sex}
          onChange={(e) => setSex(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Color"
          value={color}
          onChange={(e) => setColor(e.target.value)}
          required
        />
        <input
          className="input-field"
          type="text"
          placeholder="Size"
          value={size}
          onChange={(e) => setSize(e.target.value)}
          required
        />
        <button className="submit-btn" type="submit">
          {editId !== null ? 'Update Pet' : 'Add Pet'}
        </button>
      </form>

      <h3>Pet List</h3>
      {pets.length === 0 ? (
        <p>No pets available</p>
      ) : (
        <table className="pet-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Breed</th>
              <th>Species</th>
              <th>Age</th>
              <th>Sex</th>
              <th>Color</th>
              <th>Size</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pets.map((pet) => (
              <tr key={pet.id}>
                <td>{pet.name}</td>
                <td>{pet.breed}</td>
                <td>{pet.species}</td>
                <td>{pet.age}</td>
                <td>{pet.sex}</td>
                <td>{pet.color}</td>
                <td>{pet.size}</td>
                <td>
                  <button onClick={() => handleEdit(pet)}>Edit</button>
                  <button onClick={() => handleDelete(pet.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default PetManagement;
