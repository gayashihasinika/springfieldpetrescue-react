import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../assets/css/usermanagement.css';

const UserManagement =()=>{
    const [users, setUsers] = useState([]);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [editId, setEditId] = useState(null);

    useEffect(() => {
        fetchUsers();
      }, []);

    // Handle form submit
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editId !== null) {
                // Update user
                await axios.put(`http://localhost:3001/users/${editId}`, { name, email });
            } else {
                // Add new user
                await axios.post('http://localhost:3001/users', { name, email });
            }
            setName('');
            setEmail('');
            setEditId(null);
            fetchUsers(); // Refresh the user list after submission
        } catch (error) {
            console.error('Error submitting form', error);
        }
    };

    // Handle edit user
    const handleEdit = (user) => {
        setName(user.name);
        setEmail(user.email);
        setEditId(user.id);
    };
    

    // Handle delete user
    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:3001/users/${id}`);
            fetchUsers(); // Refresh the user list after deletion
        } catch (error) {
            console.error('Error deleting user', error);
        }
    };

      // Fetch all users from backend
        const fetchUsers = async () => {
            try {
            const response = await axios.get('http://localhost:3001/users');
            setUsers(response.data);
            } catch (error) {
            console.error('Error fetching users', error);
            }
        };

      return (
        <div className="container">
          <h2 className="header">User Management</h2>
          <form className="form" onSubmit={handleSubmit}>
            <input
              className="input-field"
              type="text"
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              className="input-field"
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button className="submit-btn" type="submit">
              {editId !== null ? 'Update User' : 'Add User'}
            </button>
          </form>
    
          <h3>User List</h3>
          {users.length === 0 ? (
            <p>No users available</p>
          ) : (
            <table className="user-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>
                      <button onClick={() => handleEdit(user)}>Edit</button>
                      <button onClick={() => handleDelete(user.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      );
}
export default UserManagement;