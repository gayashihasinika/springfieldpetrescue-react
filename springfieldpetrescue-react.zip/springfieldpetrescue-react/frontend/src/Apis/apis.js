export const apis={
    getCities:'geo/cities/5.json?key=Vbj5mcz5ZtvnmTLvn5yVcjgctdPsbawh',
   
}