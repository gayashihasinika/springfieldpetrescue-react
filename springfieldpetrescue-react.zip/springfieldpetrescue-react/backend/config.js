module.exports = {
    host: 'localhost',
    user: 'root',  // Change to your MySQL user
    password: '',  // Change to your MySQL password
    database: 'sprinfieldpetrescuedb'  // Change to your MySQL database
  };